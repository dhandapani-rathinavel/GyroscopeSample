//
//  CustomLayout.swift
//  CVCustomLayout
//
//  Created by enQoS iOS on 26/10/17.
//  Copyright © 2017 DreamCare. All rights reserved.
//

import Foundation
import  UIKit

class SpyderLayout : UICollectionViewLayout {
    fileprivate var numberOfColumns = 1
    fileprivate var cellPadding: CGFloat = 6
    fileprivate var contentHeight: CGFloat = 0
    fileprivate var cache = [UICollectionViewLayoutAttributes]()

    fileprivate var contentWidth: CGFloat {
        guard let collectionView = collectionView else {
            return 0
        }
        let insets = collectionView.contentInset
        return collectionView.bounds.width - (insets.left + insets.right)
    }

    override var collectionViewContentSize: CGSize {
        if let collectionView = collectionView {
            return CGSize(width: collectionView.frame.size.width, height: collectionView.frame.size.height)
        }
        else {
            return CGSize(width: 100,  height: 100)
        }
    }
    
    override func prepare() {
    
        guard cache.isEmpty == true, let collectionView = collectionView else {
            return
        }
        
        let cellHeight:CGFloat = 50
        let yPadding:CGFloat = 10
        let yCenter = collectionView.frame.size.height / 2
        
        var cellArea = collectionView.frame.size.width / CGFloat(collectionView.numberOfItems(inSection: 0))
        cellArea = cellArea * 1.09
        
        for item in 0..<collectionView.numberOfItems(inSection: 0) {
            let y:CGFloat!
            var x = cellArea * CGFloat(item)
            if item % 2 == 0 {
                y = yCenter - yPadding
            }
            else {
                y = yCenter - (cellHeight - yPadding)
            }
            if item != 0 {
                x = x - (((x*10) / 110))
            }
            let frame = CGRect(x: x, y: y, width: cellArea, height: cellArea + 30)
           
            let attributes = UICollectionViewLayoutAttributes(forCellWith: IndexPath.init(item: item, section: 0))
            attributes.frame = frame
            
            cache.append(attributes)
        }
    }

    override func layoutAttributesForElements(in rect: CGRect) -> [UICollectionViewLayoutAttributes]? {
        var visibleLayoutAttributes = [UICollectionViewLayoutAttributes]()
        for attributes in cache {
            if attributes.frame.intersects(rect) {
                visibleLayoutAttributes.append(attributes)
            }
        }
        return visibleLayoutAttributes
    }
    
    override func layoutAttributesForItem(at indexPath: IndexPath) -> UICollectionViewLayoutAttributes? {
        return cache[indexPath.item]
    }
}
