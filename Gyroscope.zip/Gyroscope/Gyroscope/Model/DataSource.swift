//
//  DataSource.swift
//  Gyroscope
//
//  Created by enQoS iOS on 25/10/17.
//  Copyright © 2017 DreamCare. All rights reserved.
//

import Foundation

struct DailyStep {
    let day: String!
    let date: String!
    init(day: String, date: String) {
        self.day = day
        self.date = date
    }
}

struct BriefDailyStep {
    let day: String!
    let date: String!
    init(day: String, date: String) {
        self.day = day
        self.date = date
    }
}


class DetailDataSource : NSObject, UICollectionViewDataSource {
    
    let dailyStepArray = [DailyStep.init(day: "MON", date: "OCT 23"),
                          DailyStep.init(day: "TUE", date: "OCT 24"),
                          DailyStep.init(day: "WED", date: "OCT 25"),
                          DailyStep.init(day: "THU", date: "OCT 26"),
                          DailyStep.init(day: "FRI", date: "OCT 27"),
                          DailyStep.init(day: "SAT", date: "OCT 28"),
                          DailyStep.init(day: "SUN", date: "OCT 29")]
    
    override init() {
        super.init()
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return dailyStepArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "StepsCollectionViewCell", for: indexPath) as! StepsCollectionViewCell
        cell.configureCell(data: dailyStepArray[indexPath.item])
        return cell
    }
}


class BriefDataSource : NSObject, UICollectionViewDataSource {
    
    let briefDailyStepArray = [BriefDailyStep.init(day: "MON", date: "23"),
                          BriefDailyStep.init(day: "TUE", date: "24"),
                          BriefDailyStep.init(day: "WED", date: "25"),
                          BriefDailyStep.init(day: "THU", date: "26"),
                          BriefDailyStep.init(day: "FRI", date: "27"),
                          BriefDailyStep.init(day: "SAT", date: "28"),
                          BriefDailyStep.init(day: "SUN", date: "29")]
    
    override init() {
        super.init()
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return briefDailyStepArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
       
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "BriefStepsCollectionViewCell", for: indexPath) as! BriefStepsCollectionViewCell
        cell.configureCell(data: briefDailyStepArray[indexPath.item], indexPath: indexPath)
        
        return cell
    }
}
