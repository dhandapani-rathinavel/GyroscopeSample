//
//  StepsCollectionViewCell.swift
//  Gyroscope
//
//  Created by enQoS iOS on 25/10/17.
//  Copyright © 2017 DreamCare. All rights reserved.
//

import UIKit

class StepsCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var dayLabel: UILabel!
    @IBOutlet weak var chartView: ChartView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.backgroundColor = AppColor.gBlueColor()
    }
    
    func configureCell(data: DailyStep) {
        chartView.setNeedsDisplay()
        dateLabel.text = data.date
        dayLabel.text = data.day
    }

}
