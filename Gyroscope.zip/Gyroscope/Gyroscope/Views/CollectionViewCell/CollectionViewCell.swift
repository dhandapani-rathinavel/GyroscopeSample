//
//  CollectionViewCell.swift
//  Gyroscope
//
//  Created by enQoS iOS on 25/10/17.
//  Copyright © 2017 DreamCare. All rights reserved.
//

import UIKit


class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var subTitleLabel: UILabel!
    @IBOutlet weak var imageview: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        titleLabel.textColor = AppColor.gGrayColor()
        subTitleLabel.textColor = AppColor.gGrayColor()
        
        customizeImageView()
    }
    
    func customizeImageView() {
        imageview.layer.cornerRadius = 5.0
        imageview.layer.masksToBounds = true
        
        layer.cornerRadius = 5.0
        layer.masksToBounds = true
    }
    
    func configureCell(data: CategoryData) {
        titleLabel.text = data.title
        subTitleLabel.text = data.subTitle
        imageview.image = data.image
        
        if data.isHighLighted {
            backgroundColor = AppColor.cellHighLightColor()
        }
        else {
            backgroundColor = .black
        }
    }

}
