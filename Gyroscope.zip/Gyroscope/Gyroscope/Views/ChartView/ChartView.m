//
//  ChartView.m
//  Chart
//
//  Created by DHANDAPANI R on 24/10/17.
//  Copyright © 2017 DHANDAPANI R. All rights reserved.
//

#import "ChartView.h"


@implementation ChartView
- (void)drawRect:(CGRect)rect {
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGContextSaveGState(ctx);
    CGRect frame = self.bounds;
    
    [(UIColor *)self.backgroundColor set];
    UIRectFill(frame);
    
    CGFloat columnWidth = (rect.size.width / 2) / (40 - 1);
    
    CGFloat actualWidth = MAX(1, columnWidth * (1 - 2 * (2/10.0)));
    CGFloat actualPadding = MAX(0, (columnWidth - actualWidth) / 2);
    
    int lowerBound = 0;
    int upperBound = 10;
    
    for (NSUInteger i = 0; i < 80; i++) {
        CGFloat columnHeight = lowerBound + arc4random() % (upperBound - lowerBound);
        
        if (columnHeight <= 0)
            continue;
        CGFloat columnX = i * columnWidth;
        
        UIBezierPath *rollingPath = [[UIBezierPath alloc] init];
        rollingPath = [UIBezierPath bezierPathWithRoundedRect: CGRectMake(columnX + actualPadding,
                                                                          CGRectGetHeight(frame)/2 - columnHeight/2,
                                                                          actualWidth,
                                                                          columnHeight)
                                                 cornerRadius: actualWidth];
        
        [[UIColor colorWithRed:155.0/255.0 green:202.0/255.0 blue:229.0/255.0 alpha:1] setFill];
        
        [rollingPath fill];
    }
    
    [[UIColor redColor] setStroke];
    
//    UIBezierPath *linePath = [UIBezierPath bezierPath];
//
//    linePath.lineWidth = 2.0;
//    [linePath moveToPoint: CGPointMake(CGRectGetWidth(rect) / 2 + actualPadding, CGRectGetHeight(rect) / 2)];
//    [linePath addLineToPoint: CGPointMake(CGRectGetWidth(rect), CGRectGetHeight(rect) / 2)];
//    [linePath stroke];
    
    CGContextRestoreGState(ctx);
}

@end
