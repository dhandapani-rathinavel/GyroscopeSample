//
//  ChartView.h
//  Chart
//
//  Created by DHANDAPANI R on 24/10/17.
//  Copyright © 2017 DHANDAPANI R. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChartView : UIView
@property(nonatomic,strong)NSMutableArray *equalizerBinColors;
@property(nonatomic,strong)NSMutableArray *lowFrequencyColors;
@property(nonatomic,strong)NSMutableArray *hightFrequencyColors;
@property(nonatomic,strong)NSMutableArray *equalizerBackgroundColors;
@property(nonatomic,strong)UIColor *equalizerBinColor;
- (UIColor *)equalizerBinColor;

@end
