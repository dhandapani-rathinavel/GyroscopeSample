//
//  File.swift
//  Gyroscope
//
//  Created by enQoS iOS on 25/10/17.
//  Copyright © 2017 DreamCare. All rights reserved.
//

import Foundation
import UIKit

public struct Screen {
    /// Retrieves the device bounds.
    public static var bounds: CGRect {
        return UIScreen.main.bounds
    }
    
    /// Retrieves the device width.
    public static var width: CGFloat {
        return bounds.width
    }
    
    /// Retrieves the device height.
    public static var height: CGFloat {
        return bounds.height
    }
    
    /// Retrieves the device scale.
    public static var scale: CGFloat {
        return UIScreen.main.scale
    }
}


class AppColor {
    class func gGrayColor() -> UIColor {
        return UIColor.init(red: 149.0/255.0, green: 149.0/255.0, blue: 149.0/255.0, alpha: 1)
    }
    
    class func gBlueColor() -> UIColor {
        return UIColor.init(red: 38.0/255.0, green: 130.0/255.0, blue: 172.0/255.0, alpha: 1)
    }
    
    class func cellHighLightColor() -> UIColor {
        return UIColor.init(red: 16.0/255.0, green: 23.0/255.0, blue: 29.0/255.0, alpha: 1)
    }
    
    class func gLightBlueColor() -> UIColor {
        return UIColor.init(red: 147.0/255.0, green: 187.0/255.0, blue: 227.0/255.0, alpha: 1)
    }
    
}

struct CategoryData {
    let image: UIImage!
    let title:String
    let subTitle:String
    var isHighLighted = false
    init(imageName: String, title: String, subTitle: String) {
        self.image = UIImage.init(named: imageName)!
        self.title = title
        self.subTitle = subTitle
    }
}

extension UIImage {
    /**
     Creates an Image that is a color.
     - Parameter color: The UIColor to create the image from.
     - Parameter size: The size of the image to create.
     - Returns: A UIImage that is the color passed in.
     */
    open class func image(with color: UIColor, size: CGSize) -> UIImage? {
        UIGraphicsBeginImageContextWithOptions(size, false, Screen.scale)
        guard let context = UIGraphicsGetCurrentContext() else {
            return nil
        }
        
        context.scaleBy(x: 1.0, y: -1.0)
        context.translateBy(x: 0.0, y: -size.height)
        
        context.setBlendMode(.multiply)
        
        let rect = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        color.setFill()
        context.fill(rect)
        
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image?.withRenderingMode(.alwaysOriginal)
    }
}

