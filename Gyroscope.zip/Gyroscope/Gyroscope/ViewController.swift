//
//  ViewController.swift
//  Gyroscope
//
//  Created by enQoS iOS on 25/10/17.
//  Copyright © 2017 DreamCare. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var categoryArray = [CategoryData]()
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var detailsCollectionView: UICollectionView!
    @IBOutlet weak var weeklyStepsCollectionView: UICollectionView!
    @IBOutlet weak var shareButton: UIButton!

    let detailDataSource = DetailDataSource()
    let briefDataSource = BriefDataSource()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        customizeShareButton()
        customizeNavigationBar()
        setupThumbCollectionView()
        makeDummyData()
        detailsCollectionView.isHidden = true
        weeklyStepsCollectionView.isHidden = false
    }
    
    func makeDummyData() {
        categoryArray.append(CategoryData.init(imageName: "week", title: "Week", subTitle: "The week of June 6"))
        categoryArray.append(CategoryData.init(imageName: "step", title: "Steps", subTitle: "Average 1972 steps per day"))
        categoryArray.append(CategoryData.init(imageName: "week", title: "Week", subTitle: "The week of June 6"))
        categoryArray.append(CategoryData.init(imageName: "step", title: "Steps", subTitle: "Average 1972 steps per day"))
    }

    override func viewDidAppear(_ animated: Bool) {
        setDataSourceForDetailCollectionView()
        setDataSourceForWeeklyStepCollectionView()
    }
    
    func customizeNavigationBar() {
        self.navigationController?.navigationBar.setBackgroundImage(UIImage.image(with: .black, size: CGSize.init(width: self.view.frame.size.width, height: 84)), for: .default)
        
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor : UIColor.white as Any]
    }
    
    func setupThumbCollectionView() {
        let nib = UINib(nibName: "CollectionViewCell", bundle:nil)
        self.collectionView.register(nib, forCellWithReuseIdentifier: "CollectionViewCell")
        self.collectionView.dataSource = self
        self.collectionView.delegate = self
        
        let flowLayout = UICollectionViewFlowLayout.init()
        flowLayout.itemSize = CGSize(width: 107, height: 150)
        flowLayout.scrollDirection = .horizontal
        self.collectionView.setCollectionViewLayout(flowLayout, animated: true)
    }
    
    func setDataSourceForDetailCollectionView() {
        let nib = UINib(nibName: "StepsCollectionViewCell", bundle:nil)
        self.detailsCollectionView.register(nib, forCellWithReuseIdentifier: "StepsCollectionViewCell")
        self.detailsCollectionView.backgroundColor = AppColor.gBlueColor()
        self.detailsCollectionView.dataSource = detailDataSource
        
        let flowLayout = UICollectionViewFlowLayout.init()
        flowLayout.itemSize = CGSize(width: detailsCollectionView.frame.size.width, height: detailsCollectionView.frame.size.height/7)
        flowLayout.scrollDirection = .vertical
        self.detailsCollectionView.setCollectionViewLayout(flowLayout, animated: true)
        
        self.detailsCollectionView.layer.cornerRadius = 5.0
        self.detailsCollectionView.layer.masksToBounds = true
        self.detailsCollectionView.reloadData()
    }
    
    func setDataSourceForWeeklyStepCollectionView() {
        let nib = UINib(nibName: "BriefStepsCollectionViewCell", bundle:nil)
        self.weeklyStepsCollectionView.register(nib, forCellWithReuseIdentifier: "BriefStepsCollectionViewCell")
        self.weeklyStepsCollectionView.backgroundColor = AppColor.cellHighLightColor()
        self.weeklyStepsCollectionView.dataSource = briefDataSource
        
        let spyderLayout = SpyderLayout()
        self.weeklyStepsCollectionView.setCollectionViewLayout(spyderLayout, animated: true)
        
        self.weeklyStepsCollectionView.layer.cornerRadius = 5.0
        self.weeklyStepsCollectionView.layer.masksToBounds = true
        self.weeklyStepsCollectionView.reloadData()
    }
    
    func customizeShareButton() {
        shareButton.layer.cornerRadius = 5.0
        shareButton.layer.masksToBounds = true
        shareButton.layer.borderColor = AppColor.gBlueColor().cgColor
        shareButton.layer.borderWidth = 3.0
        shareButton.setTitleColor(AppColor.gLightBlueColor(), for: .normal)
    }
}


extension ViewController : UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {

        categoryArray = categoryArray.map({ (data) -> CategoryData in
            var newData = data
            newData.isHighLighted = false
            return newData
        })
        categoryArray[indexPath.item].isHighLighted = true
        self.collectionView.reloadData()
        
        if indexPath.item % 2 == 0{
            detailsCollectionView.isHidden = true
            weeklyStepsCollectionView.isHidden = false
        }
        else {
            detailsCollectionView.isHidden = false
            weeklyStepsCollectionView.isHidden = true
        }
    }
}

extension ViewController : UICollectionViewDataSource {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return categoryArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = self.collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell", for: indexPath) as! CollectionViewCell
        cell.configureCell(data: categoryArray[indexPath.item])
        return cell
    }
}


